function rmoveto(x,y)
global PSFID

fprintf(PSFID,'%g %g RM\n',x,y);