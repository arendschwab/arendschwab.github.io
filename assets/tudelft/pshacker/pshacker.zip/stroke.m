function stroke
global PSFID

fprintf(PSFID,'ST\n');
