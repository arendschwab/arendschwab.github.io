function gsave
global PSFID

fprintf(PSFID,'GS\n');
