function closepath
global PSFID

fprintf(PSFID,'CP\n');
