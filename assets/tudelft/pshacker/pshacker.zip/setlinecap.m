function setlinecap(x)
global PSFID

fprintf(PSFID,'%g setlinecap\n',x);