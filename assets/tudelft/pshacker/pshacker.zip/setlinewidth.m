function setlinewidth(x)
global PSFID

fprintf(PSFID,'%g SL\n',x);