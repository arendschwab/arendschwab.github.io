function title(str)
global PSFID

fprintf(PSFID,'%%%%Title: %s\n',str);