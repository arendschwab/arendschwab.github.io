function cirle3(m3,dir3,radius)
%function cirle3(m3,dir3,radius)

[n,d]=size(m3);
m2=project(m3);
for i=1:n
  [dm,id]=min(abs(dir3(i,:)));
  r3=[0 0 0];
  r3(id)=1;
  r3=cross(r3,dir3);
  r3=r3.*(radius/norm(r3));
  mu=linspace(0,2*pi,64);
  np=length(mu);
  c3=zeros(np,3);
  lu=[1 0 0 0];
  for j=1:np
    lu(1)=cos(mu(j)/2);
	lu(2:4)=dir3(i,:).*sin(mu(j)/2);
	Ru=rmatl(lu);
	c3(j,:)=m3(i,:)+r3*Ru.';
  end
  c2=project(c3);
  moveto(c2(1,1),c2(1,2));
  for j=2:np
    lineto(c2(j,1),c2(j,2));
  end
end
