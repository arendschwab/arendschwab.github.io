function pijl(x1,y1,x2,y2,dx,dy)
%function pijl(x1,y1,x2,y2,dx,dy)

global PSFID

if nargin==4
	dx=5;
	dy=1.5;
end
angle=atan2(y2-y1,x2-x1);
moveto(x1,y1)
lineto(x2-5/6*dx*cos(angle),y2-5/6*dx*sin(angle))
pijlpunt(x2,y2,angle*180/pi,dx,dy)