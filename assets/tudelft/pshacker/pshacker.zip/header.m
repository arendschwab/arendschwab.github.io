function header
global PSFID

fprintf(PSFID,'%%!PS-Adobe-3.0\n');
