function showback(str)
global PSFID
fprintf(PSFID,'(%s) SHB\n',str);
