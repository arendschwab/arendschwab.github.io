function setmiterlimit(x)
global PSFID

fprintf(PSFID,'%g setmiterlimit\n',x);