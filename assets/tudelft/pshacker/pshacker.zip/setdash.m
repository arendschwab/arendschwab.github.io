function setdash(arr,offset)
global PSFID

fprintf(PSFID,'[');
fprintf(PSFID,'%g ',arr);
fprintf(PSFID,'] %g SD\n',offset);