function setgray(x)
global PSFID

fprintf(PSFID,'%g SG\n',x);