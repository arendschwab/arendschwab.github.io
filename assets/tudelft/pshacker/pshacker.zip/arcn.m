function arcn(x,y,r,ang1,ang2)
global PSFID

fprintf(PSFID,'%g %g %g %g %g arcn\n',x,y,r,ang1,ang2);