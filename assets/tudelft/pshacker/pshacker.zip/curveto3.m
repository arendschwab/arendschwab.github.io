function curveto3(xyz)
%function curveto3(xyz)

[n,d]=size(xyz);
uv=project(xyz);
moveto(uv(1,1),uv(1,2))
curveto(uv(2,1),uv(2,2),uv(3,1),uv(3,2),uv(4,1),uv(4,2))
