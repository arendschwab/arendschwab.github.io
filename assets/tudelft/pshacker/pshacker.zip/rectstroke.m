function rectstroke(x,y,width,height)
global PSFID

fprintf(PSFID,'%g %g %g %g RS\n',x,y,width,height);