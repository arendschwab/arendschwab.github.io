function mfixit(x,y,b,h,c,phi)

gsave
translate(x,y)
rotate(phi)
newpath
moveto(-b/2,0)
rlineto(b,0)
stroke
newpath
setlinewidth(0.48)
moveto(-b/2,-h)
for i=1:1:b/c
  rlineto(h,h)
  rmoveto(c-h,-h)
end
stroke
grestore

