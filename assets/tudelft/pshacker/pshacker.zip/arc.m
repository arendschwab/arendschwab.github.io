function arc(x,y,r,ang1,ang2)
global PSFID

fprintf(PSFID,'%g %g %g %g %g arc\n',x,y,r,ang1,ang2);