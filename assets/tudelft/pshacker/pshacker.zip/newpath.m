function newpath
global PSFID

fprintf(PSFID,'NP\n');
