function showm(str)
global PSFID
fprintf(PSFID,'(%s) SHM\n',str);
