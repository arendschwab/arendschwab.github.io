function lineto3(xyz)
%function lineto3(xyz)

[n,d]=size(xyz);
uv=project(xyz);
for i=1:n
  lineto(uv(i,1),uv(i,2))
end