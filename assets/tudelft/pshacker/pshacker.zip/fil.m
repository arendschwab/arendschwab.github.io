function fil
global PSFID

fprintf(PSFID,'fill\n');
