function rectclip(x,y,width,height)
global PSFID
 
fprintf(PSFID,'%g %g %g %g rectclip\n',x,y,width,height);