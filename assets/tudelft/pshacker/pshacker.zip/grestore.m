function grestore
global PSFID

fprintf(PSFID,'GR\n');
