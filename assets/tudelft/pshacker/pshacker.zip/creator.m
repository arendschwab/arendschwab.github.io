function creator(str)
global PSFID

fprintf(PSFID,'%%%%Creator: %s\n',str);