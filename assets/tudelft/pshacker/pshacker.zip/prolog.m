function prolog
global PSFID

fprintf(PSFID,'%%%%BeginProlog\n');
fprintf(PSFID,'/CP /closepath load def\n');
fprintf(PSFID,'/CT /curveto load def\n');
fprintf(PSFID,'/GR /grestore load def\n');
fprintf(PSFID,'/GS /gsave load def\n');
fprintf(PSFID,'/L  /lineto load def\n');
fprintf(PSFID,'/M  /moveto load def\n');
fprintf(PSFID,'/NP /newpath load def\n');
fprintf(PSFID,'/RC /rcurveto load def\n');
fprintf(PSFID,'/RF /rectfill load def\n');
fprintf(PSFID,'/RS /rectstroke load def\n');
fprintf(PSFID,'/RL /rlineto load def\n');
fprintf(PSFID,'/RM /rmoveto load def\n');
fprintf(PSFID,'/RO /rotate load def\n');
fprintf(PSFID,'/SC /scale load def\n');
fprintf(PSFID,'/SF /selectfont load def\n');
fprintf(PSFID,'/SD /setdash load def\n');
fprintf(PSFID,'/SG /setgray load def\n');
fprintf(PSFID,'/SL /setlinewidth load def\n');
fprintf(PSFID,'/S  /show load def\n');
fprintf(PSFID,'/ST /stroke load def\n');
fprintf(PSFID,'/TR /translate load def\n');
fprintf(PSFID,'/SHB {dup stringwidth pop neg exch show 0 rmoveto} def\n');
fprintf(PSFID,'/SHL {dup stringwidth pop neg 0 rmoveto show} def\n');
fprintf(PSFID,'/SHM {dup stringwidth pop 2 div neg 0 rmoveto show} def\n');
fprintf(PSFID,'%%%%EndProlog\n');
