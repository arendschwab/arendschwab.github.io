function lineto(x,y)
global PSFID

fprintf(PSFID,'%g %g L\n',x,y);