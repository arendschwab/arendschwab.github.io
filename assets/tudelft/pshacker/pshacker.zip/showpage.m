function showpage
global PSFID

fprintf(PSFID,'showpage\n');
