function msupport(x,y,r,phi)

gsave
translate(x,y)
rotate(phi)
h=2.5*r;
b=3*r;
d=2*r;
l=7*r;
newpath
moveto(0,0)
rlineto(-b/2,-h)
rlineto(b,0)
closepath
stroke
mjoint(0,0,r)
mfixit(0,-h,l,d,1.5*r,0)
grestore

