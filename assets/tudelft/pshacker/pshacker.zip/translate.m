function translate(x,y)
global PSFID

fprintf(PSFID,'%g %g TR\n',x,y);