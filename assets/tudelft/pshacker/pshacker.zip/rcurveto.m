function rcurveto(dx1,dy1,dx2,dy2,dx3,dy3)
global PSFID

fprintf(PSFID,'%g %g %g %g %g %g RC\n',dx1,dy1,dx2,dy2,dx3,dy3);