function showl(str)
global PSFID
fprintf(PSFID,'(%s) SHL\n',str);
