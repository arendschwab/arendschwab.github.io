function boundingbox(llx,lly,urx,ury)
global PSFID

fprintf(PSFID,'%%%%BoundingBox: %g %g %g %g\n',llx,lly,urx,ury);
