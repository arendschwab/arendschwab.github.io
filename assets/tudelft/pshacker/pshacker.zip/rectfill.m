function rectfill(x,y,width,height)
global PSFID

fprintf(PSFID,'%g %g %g %g RF\n',x,y,width,height);