function R=Rmat3(ias,hoek)

R=eye(3);
c=cos(hoek);
s=sin(hoek);
Rsub=[c -s
      s  c];
if ias==1
  R([2 3],[2 3])=Rsub;
elseif ias==2
  R([3 1],[3 1])=Rsub;
elseif ias==3
  R([1 2],[1 2])=Rsub;
end