function pijlpunt(xp,yp,angle,dx,dy)

gsave
newpath
moveto(xp,yp)
rotate(angle)
scale(dx/6,dy/2)
rcurveto(-1,0,-4,1,-6,2)
rcurveto(1,-2,1,-2,0,-4)
rcurveto(1,1,5,2,6,2)
closepath
fil
grestore