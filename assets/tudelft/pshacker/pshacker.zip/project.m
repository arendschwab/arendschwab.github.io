function uv=project(xyz);
global PROMAT
% function uv=project(xyz);
% global PROMAT
% 3D projection uv=PROMAT*xyz
% Take the standard viewing
%PROMAT=[-0.7934    0.6088         0
%        -0.3044   -0.3967    0.8660];

uv=(PROMAT*xyz.').';
