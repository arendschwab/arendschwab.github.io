function mcmmarker(x,y,r,gray)
%function mcmmarker(x,y,r,gray)


gsave
if nargin==3
	gray=0;
end
newpath
setgray(1)
circle(x,y,r)
fil
newpath
setgray(gray)
setlinewidth(0)
moveto(x,y)
arc(x,y,r,0,90)
lineto(x,y)
arc(x,y,r,180,270)
lineto(x,y)
fil
%grestore
newpath
circle(x,y,r)
% % added croshair lines
% rc=1.5*r;
% moveto(x-rc,y)
% lineto(x+rc,y)
% moveto(x,y-rc)
% lineto(x,y+rc)
stroke
grestore