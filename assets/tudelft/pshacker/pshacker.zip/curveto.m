function curveto(x1,y1,x2,y2,x3,y3)
global PSFID

fprintf(PSFID,'%g %g %g %g %g %g CT\n',x1,y1,x2,y2,x3,y3);