function initclip
global PSFID

fprintf(PSFID,'initclip\n');
