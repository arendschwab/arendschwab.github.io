function arct(x,y,r,ang1,ang2)
global PSFID

fprintf(PSFID,'%g %g %g %g %g arct\n',x,y,r,ang1,ang2);