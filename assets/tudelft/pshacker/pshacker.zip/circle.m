function circle(x,y,r)
global PSFID

fprintf(PSFID,'%g %g M\n',x+r,y);
fprintf(PSFID,'%g %g %g 0 360 arc\n',x,y,r);