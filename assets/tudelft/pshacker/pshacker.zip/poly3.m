function poly3(xyz)

moveto3(xyz(1,:))
lineto3(xyz(2:end,:))