function comment(str)
global PSFID

fprintf(PSFID,'%%%s\n',str);