function moveto3(xyz)
%function moveto3(xyz)

[n,d]=size(xyz);
uv=project(xyz);
for i=1:n
  moveto(uv(i,1),uv(i,2))
end