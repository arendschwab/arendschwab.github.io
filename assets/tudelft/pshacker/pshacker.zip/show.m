function show(str)
global PSFID

fprintf(PSFID,'(%s) S\n',str);