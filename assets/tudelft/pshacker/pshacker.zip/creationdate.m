function creationdate(str)
global PSFID

fprintf(PSFID,'%%%%CreationDate: %s\n',str);