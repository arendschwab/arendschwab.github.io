function selectfont(fontname,fontsize)
global PSFID

fprintf(PSFID,'/%s %g SF\n',fontname,fontsize);