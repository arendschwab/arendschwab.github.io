function pijl3(p,q)

p2=project(p);
q2=project(q);
pijl(p2(1),p2(2),q2(1),q2(2))