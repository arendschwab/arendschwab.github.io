function rlineto(x,y)
global PSFID

fprintf(PSFID,'%g %g RL\n',x,y);