function moveto(x,y)
global PSFID

fprintf(PSFID,'%g %g M\n',x,y);