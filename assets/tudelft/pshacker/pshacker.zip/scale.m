function scale(sx,sy)
global PSFID

fprintf(PSFID,'%g %g SC\n',sx,sy);