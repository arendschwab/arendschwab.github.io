function mjoint(x,y,r)

gsave
newpath
setgray(1)
circle(x,y,r)
fil
grestore
circle(x,y,r)