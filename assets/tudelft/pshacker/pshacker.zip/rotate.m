function rotate(dalfa)
global PSFID

fprintf(PSFID,'%g RO\n',dalfa);