function eof
global PSFID

fprintf(PSFID,'%%%%EOF\n');
