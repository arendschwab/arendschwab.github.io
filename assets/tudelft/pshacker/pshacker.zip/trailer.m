function trailer
global PSFID

fprintf(PSFID,'%%%%Trailer\n');
