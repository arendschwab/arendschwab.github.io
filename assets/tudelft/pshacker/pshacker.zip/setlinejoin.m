function setlinejoin(x)
global PSFID

fprintf(PSFID,'%g setlinejoin\n',x);